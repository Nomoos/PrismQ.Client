Frontend/TaskManager - Deployment Package
==========================================

Build Date: Tue Nov 11 11:32:30 UTC 2025
Build Script: npm run build (or build-and-package.sh)
Git Commit: dbdf4b3
Git Branch: copilot/deploy-frontend-taskmanager

Package Contents:
-----------------
- assets/          : Production build files (JS, CSS, images)
- index.html       : Main application entry point
- deploy.php       : Deployment wizard (open in browser)
- deploy-auto.php  : Automated deployment script (CLI)
- deploy-deploy.php: Script downloader
- .htaccess        : Apache SPA routing configuration
- .htaccess.example: Backup/template for .htaccess

Deployment Options:
-------------------

OPTION 1: Upload via FTP/SFTP (Recommended for Vedos/Wedos)
1. Upload all files from dist/ folder to your web root
2. Open https://your-domain.com/deploy.php in browser
3. Follow the deployment wizard

OPTION 2: Manual Setup
1. Upload all files to your web root
2. Ensure .htaccess is in place (for SPA routing)
3. Open https://your-domain.com/ in browser
4. Configure API connection in Settings page

OPTION 3: Automated CLI Deployment (if PHP CLI available)
1. Upload deploy-auto.php to server
2. SSH to server
3. Run: php deploy-auto.php --version=latest

Requirements:
-------------
- Web server with PHP 7.4+ (for deployment scripts only)
- Apache with mod_rewrite (or equivalent for SPA routing)
- Backend/TaskManager API running and accessible
- HTTPS recommended for production

Configuration:
--------------
The application is configured via environment variables at BUILD TIME.
To change API URL or other settings:
1. Edit Frontend/TaskManager/.env
2. Rebuild: npm run build
3. Re-upload dist/

Support:
--------
- Documentation: Frontend/TaskManager/README.md
- Issues: GitHub Issues
- API Docs: Frontend/TaskManager/docs/API_INTEGRATION.md

